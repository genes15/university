﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace internacionalizacion
{
    public partial class Materia : Form
    {
        public Materia()
        {
            InitializeComponent();
        }

        private void materiaBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.materiaBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.internacionalizacionDataSet2);

        }

        private void Materia_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'internacionalizacionDataSet2.Materia' Puede moverla o quitarla según sea necesario.
            this.materiaTableAdapter.Fill(this.internacionalizacionDataSet2.Materia);

        }

        private void Atras_Click(object sender, EventArgs e)
        {
            this.Hide();
            Menu jframe = new Menu();
            jframe.Show();
        }
    }
}
