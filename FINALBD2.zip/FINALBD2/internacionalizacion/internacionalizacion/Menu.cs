﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace internacionalizacion
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void Atras_Click(object sender, EventArgs e)
        {
            this.Hide();
            Ingreso hola = new Ingreso();
            hola.Show();

        }

        private void Facultad_Click(object sender, EventArgs e)
        {
            this.Hide();
            Facultad facu = new Facultad();
            facu.Show();
        }

        private void Admisiones_Click(object sender, EventArgs e)
        {
            this.Hide();
            Admisiones admin = new Admisiones();
            admin.Show();
        }

        private void Menu_Load(object sender, EventArgs e)
        {

        }

        private void Estudiante_Click(object sender, EventArgs e)
        {
            this.Hide();
            Estudiante estu = new Estudiante();
            estu.Show();
        }

        private void Materias_Click(object sender, EventArgs e)
        {
            this.Hide();
            Materia mate = new Materia();
            mate.Show();
        }

        private void Notas_Click(object sender, EventArgs e)
        {
            this.Hide();
            Notas nota = new Notas();
            nota.Show();
        }

        private void Programa_Click(object sender, EventArgs e)
        {
            this.Hide();
            Programa pro = new Programa();
            pro.Show();
        }

        private void Universidad_Click(object sender, EventArgs e)
        {
            this.Hide();
            Universidad uni = new Universidad();
            uni.Show();
        }

        private void Solicitud_Click(object sender, EventArgs e)
        {
            this.Hide();
            Solicitud soli = new Solicitud();
            soli.Show();
        }
    }
}
