﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace internacionalizacion
{
    public partial class Facultad : Form
    {
        public Facultad()
        {
            InitializeComponent();
        }

        private void facultadBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.facultadBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.internacionalizacionDataSet2);

        }

        private void Facultad_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'internacionalizacionDataSet2.Facultad' Puede moverla o quitarla según sea necesario.
            this.facultadTableAdapter.Fill(this.internacionalizacionDataSet2.Facultad);

        }

        private void Atras_Click(object sender, EventArgs e)
        {
            this.Hide();
            Menu jframe = new Menu();
            jframe.Show();
        }
    }
}
