﻿namespace internacionalizacion
{
    partial class Universidad
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label idUniversidadLabel;
            System.Windows.Forms.Label solicitud_IDsolicitudLabel;
            System.Windows.Forms.Label nombreLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Universidad));
            this.internacionalizacionDataSet2 = new internacionalizacion.internacionalizacionDataSet2();
            this.universidadBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.universidadTableAdapter = new internacionalizacion.internacionalizacionDataSet2TableAdapters.UniversidadTableAdapter();
            this.tableAdapterManager = new internacionalizacion.internacionalizacionDataSet2TableAdapters.TableAdapterManager();
            this.universidadBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.universidadBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.universidadDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Atras = new System.Windows.Forms.Button();
            this.idUniversidadTextBox = new System.Windows.Forms.TextBox();
            this.solicitud_IDsolicitudTextBox = new System.Windows.Forms.TextBox();
            this.nombreTextBox = new System.Windows.Forms.TextBox();
            idUniversidadLabel = new System.Windows.Forms.Label();
            solicitud_IDsolicitudLabel = new System.Windows.Forms.Label();
            nombreLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.internacionalizacionDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.universidadBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.universidadBindingNavigator)).BeginInit();
            this.universidadBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.universidadDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // idUniversidadLabel
            // 
            idUniversidadLabel.AutoSize = true;
            idUniversidadLabel.BackColor = System.Drawing.SystemColors.ActiveBorder;
            idUniversidadLabel.Location = new System.Drawing.Point(435, 369);
            idUniversidadLabel.Name = "idUniversidadLabel";
            idUniversidadLabel.Size = new System.Drawing.Size(78, 13);
            idUniversidadLabel.TabIndex = 3;
            idUniversidadLabel.Text = "Id Universidad:";
            // 
            // solicitud_IDsolicitudLabel
            // 
            solicitud_IDsolicitudLabel.AutoSize = true;
            solicitud_IDsolicitudLabel.BackColor = System.Drawing.SystemColors.ActiveBorder;
            solicitud_IDsolicitudLabel.Location = new System.Drawing.Point(435, 395);
            solicitud_IDsolicitudLabel.Name = "solicitud_IDsolicitudLabel";
            solicitud_IDsolicitudLabel.Size = new System.Drawing.Size(102, 13);
            solicitud_IDsolicitudLabel.TabIndex = 5;
            solicitud_IDsolicitudLabel.Text = "Solicitud IDsolicitud:";
            // 
            // nombreLabel
            // 
            nombreLabel.AutoSize = true;
            nombreLabel.BackColor = System.Drawing.SystemColors.ActiveBorder;
            nombreLabel.Location = new System.Drawing.Point(435, 421);
            nombreLabel.Name = "nombreLabel";
            nombreLabel.Size = new System.Drawing.Size(47, 13);
            nombreLabel.TabIndex = 7;
            nombreLabel.Text = "Nombre:";
            // 
            // internacionalizacionDataSet2
            // 
            this.internacionalizacionDataSet2.DataSetName = "internacionalizacionDataSet2";
            this.internacionalizacionDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // universidadBindingSource
            // 
            this.universidadBindingSource.DataMember = "Universidad";
            this.universidadBindingSource.DataSource = this.internacionalizacionDataSet2;
            // 
            // universidadTableAdapter
            // 
            this.universidadTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AdmisionesTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.EstudianteTableAdapter = null;
            this.tableAdapterManager.FacultadTableAdapter = null;
            this.tableAdapterManager.MateriaTableAdapter = null;
            this.tableAdapterManager.NotasTableAdapter = null;
            this.tableAdapterManager.programaTableAdapter = null;
            this.tableAdapterManager.SolicitudTableAdapter = null;
            this.tableAdapterManager.UniversidadTableAdapter = this.universidadTableAdapter;
            this.tableAdapterManager.UpdateOrder = internacionalizacion.internacionalizacionDataSet2TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // universidadBindingNavigator
            // 
            this.universidadBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.universidadBindingNavigator.BindingSource = this.universidadBindingSource;
            this.universidadBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.universidadBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.universidadBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.universidadBindingNavigatorSaveItem});
            this.universidadBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.universidadBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.universidadBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.universidadBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.universidadBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.universidadBindingNavigator.Name = "universidadBindingNavigator";
            this.universidadBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.universidadBindingNavigator.Size = new System.Drawing.Size(1191, 25);
            this.universidadBindingNavigator.TabIndex = 0;
            this.universidadBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Agregar nuevo";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 22);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Número total de elementos";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Eliminar";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Mover primero";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Mover anterior";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Posición";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Posición actual";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Mover siguiente";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Mover último";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // universidadBindingNavigatorSaveItem
            // 
            this.universidadBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.universidadBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("universidadBindingNavigatorSaveItem.Image")));
            this.universidadBindingNavigatorSaveItem.Name = "universidadBindingNavigatorSaveItem";
            this.universidadBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.universidadBindingNavigatorSaveItem.Text = "Guardar datos";
            this.universidadBindingNavigatorSaveItem.Click += new System.EventHandler(this.universidadBindingNavigatorSaveItem_Click);
            // 
            // universidadDataGridView
            // 
            this.universidadDataGridView.AutoGenerateColumns = false;
            this.universidadDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.universidadDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3});
            this.universidadDataGridView.DataSource = this.universidadBindingSource;
            this.universidadDataGridView.Location = new System.Drawing.Point(802, 321);
            this.universidadDataGridView.Name = "universidadDataGridView";
            this.universidadDataGridView.Size = new System.Drawing.Size(344, 240);
            this.universidadDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "IdUniversidad";
            this.dataGridViewTextBoxColumn1.HeaderText = "IdUniversidad";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Solicitud_IDsolicitud";
            this.dataGridViewTextBoxColumn2.HeaderText = "Solicitud_IDsolicitud";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Nombre";
            this.dataGridViewTextBoxColumn3.HeaderText = "Nombre";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // Atras
            // 
            this.Atras.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.Atras.Location = new System.Drawing.Point(734, 156);
            this.Atras.Name = "Atras";
            this.Atras.Size = new System.Drawing.Size(75, 23);
            this.Atras.TabIndex = 2;
            this.Atras.Text = "Atras";
            this.Atras.UseVisualStyleBackColor = false;
            this.Atras.Click += new System.EventHandler(this.Atras_Click);
            // 
            // idUniversidadTextBox
            // 
            this.idUniversidadTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.universidadBindingSource, "IdUniversidad", true));
            this.idUniversidadTextBox.Location = new System.Drawing.Point(543, 366);
            this.idUniversidadTextBox.Name = "idUniversidadTextBox";
            this.idUniversidadTextBox.Size = new System.Drawing.Size(100, 20);
            this.idUniversidadTextBox.TabIndex = 4;
            // 
            // solicitud_IDsolicitudTextBox
            // 
            this.solicitud_IDsolicitudTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.universidadBindingSource, "Solicitud_IDsolicitud", true));
            this.solicitud_IDsolicitudTextBox.Location = new System.Drawing.Point(543, 392);
            this.solicitud_IDsolicitudTextBox.Name = "solicitud_IDsolicitudTextBox";
            this.solicitud_IDsolicitudTextBox.Size = new System.Drawing.Size(100, 20);
            this.solicitud_IDsolicitudTextBox.TabIndex = 6;
            // 
            // nombreTextBox
            // 
            this.nombreTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.universidadBindingSource, "Nombre", true));
            this.nombreTextBox.Location = new System.Drawing.Point(543, 418);
            this.nombreTextBox.Name = "nombreTextBox";
            this.nombreTextBox.Size = new System.Drawing.Size(100, 20);
            this.nombreTextBox.TabIndex = 8;
            // 
            // Universidad
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::internacionalizacion.Properties.Resources.world_map_wallpaper_hd_9090;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1191, 599);
            this.Controls.Add(idUniversidadLabel);
            this.Controls.Add(this.idUniversidadTextBox);
            this.Controls.Add(solicitud_IDsolicitudLabel);
            this.Controls.Add(this.solicitud_IDsolicitudTextBox);
            this.Controls.Add(nombreLabel);
            this.Controls.Add(this.nombreTextBox);
            this.Controls.Add(this.Atras);
            this.Controls.Add(this.universidadDataGridView);
            this.Controls.Add(this.universidadBindingNavigator);
            this.Name = "Universidad";
            this.Text = "Universidad";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Universidad_Load);
            ((System.ComponentModel.ISupportInitialize)(this.internacionalizacionDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.universidadBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.universidadBindingNavigator)).EndInit();
            this.universidadBindingNavigator.ResumeLayout(false);
            this.universidadBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.universidadDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private internacionalizacionDataSet2 internacionalizacionDataSet2;
        private System.Windows.Forms.BindingSource universidadBindingSource;
        private internacionalizacionDataSet2TableAdapters.UniversidadTableAdapter universidadTableAdapter;
        private internacionalizacionDataSet2TableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator universidadBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton universidadBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView universidadDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.Button Atras;
        private System.Windows.Forms.TextBox idUniversidadTextBox;
        private System.Windows.Forms.TextBox solicitud_IDsolicitudTextBox;
        private System.Windows.Forms.TextBox nombreTextBox;
    }
}