﻿namespace internacionalizacion
{
    partial class Facultad
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label idFacultadLabel;
            System.Windows.Forms.Label nombreFacultadLabel;
            System.Windows.Forms.Label admisiones_idAdmisionesLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Facultad));
            this.internacionalizacionDataSet2 = new internacionalizacion.internacionalizacionDataSet2();
            this.facultadBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.facultadTableAdapter = new internacionalizacion.internacionalizacionDataSet2TableAdapters.FacultadTableAdapter();
            this.tableAdapterManager = new internacionalizacion.internacionalizacionDataSet2TableAdapters.TableAdapterManager();
            this.facultadBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.facultadBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.facultadDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Atras = new System.Windows.Forms.Button();
            this.idFacultadTextBox = new System.Windows.Forms.TextBox();
            this.nombreFacultadTextBox = new System.Windows.Forms.TextBox();
            this.admisiones_idAdmisionesTextBox = new System.Windows.Forms.TextBox();
            idFacultadLabel = new System.Windows.Forms.Label();
            nombreFacultadLabel = new System.Windows.Forms.Label();
            admisiones_idAdmisionesLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.internacionalizacionDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.facultadBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.facultadBindingNavigator)).BeginInit();
            this.facultadBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.facultadDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // idFacultadLabel
            // 
            idFacultadLabel.AutoSize = true;
            idFacultadLabel.BackColor = System.Drawing.SystemColors.ActiveBorder;
            idFacultadLabel.Location = new System.Drawing.Point(382, 329);
            idFacultadLabel.Name = "idFacultadLabel";
            idFacultadLabel.Size = new System.Drawing.Size(63, 13);
            idFacultadLabel.TabIndex = 3;
            idFacultadLabel.Text = "Id Facultad:";
            // 
            // nombreFacultadLabel
            // 
            nombreFacultadLabel.AutoSize = true;
            nombreFacultadLabel.BackColor = System.Drawing.SystemColors.ActiveBorder;
            nombreFacultadLabel.Location = new System.Drawing.Point(385, 358);
            nombreFacultadLabel.Name = "nombreFacultadLabel";
            nombreFacultadLabel.Size = new System.Drawing.Size(91, 13);
            nombreFacultadLabel.TabIndex = 5;
            nombreFacultadLabel.Text = "Nombre Facultad:";
            // 
            // admisiones_idAdmisionesLabel
            // 
            admisiones_idAdmisionesLabel.AutoSize = true;
            admisiones_idAdmisionesLabel.BackColor = System.Drawing.SystemColors.ActiveBorder;
            admisiones_idAdmisionesLabel.Location = new System.Drawing.Point(385, 384);
            admisiones_idAdmisionesLabel.Name = "admisiones_idAdmisionesLabel";
            admisiones_idAdmisionesLabel.Size = new System.Drawing.Size(130, 13);
            admisiones_idAdmisionesLabel.TabIndex = 7;
            admisiones_idAdmisionesLabel.Text = "Admisiones id Admisiones:";
            // 
            // internacionalizacionDataSet2
            // 
            this.internacionalizacionDataSet2.DataSetName = "internacionalizacionDataSet2";
            this.internacionalizacionDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // facultadBindingSource
            // 
            this.facultadBindingSource.DataMember = "Facultad";
            this.facultadBindingSource.DataSource = this.internacionalizacionDataSet2;
            // 
            // facultadTableAdapter
            // 
            this.facultadTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AdmisionesTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.EstudianteTableAdapter = null;
            this.tableAdapterManager.FacultadTableAdapter = this.facultadTableAdapter;
            this.tableAdapterManager.MateriaTableAdapter = null;
            this.tableAdapterManager.NotasTableAdapter = null;
            this.tableAdapterManager.programaTableAdapter = null;
            this.tableAdapterManager.SolicitudTableAdapter = null;
            this.tableAdapterManager.UniversidadTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = internacionalizacion.internacionalizacionDataSet2TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // facultadBindingNavigator
            // 
            this.facultadBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.facultadBindingNavigator.BindingSource = this.facultadBindingSource;
            this.facultadBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.facultadBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.facultadBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.facultadBindingNavigatorSaveItem});
            this.facultadBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.facultadBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.facultadBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.facultadBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.facultadBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.facultadBindingNavigator.Name = "facultadBindingNavigator";
            this.facultadBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.facultadBindingNavigator.Size = new System.Drawing.Size(1333, 25);
            this.facultadBindingNavigator.TabIndex = 0;
            this.facultadBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Agregar nuevo";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 22);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Número total de elementos";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Eliminar";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Mover primero";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Mover anterior";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Posición";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Posición actual";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Mover siguiente";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Mover último";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // facultadBindingNavigatorSaveItem
            // 
            this.facultadBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.facultadBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("facultadBindingNavigatorSaveItem.Image")));
            this.facultadBindingNavigatorSaveItem.Name = "facultadBindingNavigatorSaveItem";
            this.facultadBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.facultadBindingNavigatorSaveItem.Text = "Guardar datos";
            this.facultadBindingNavigatorSaveItem.Click += new System.EventHandler(this.facultadBindingNavigatorSaveItem_Click);
            // 
            // facultadDataGridView
            // 
            this.facultadDataGridView.AutoGenerateColumns = false;
            this.facultadDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.facultadDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3});
            this.facultadDataGridView.DataSource = this.facultadBindingSource;
            this.facultadDataGridView.Location = new System.Drawing.Point(853, 261);
            this.facultadDataGridView.Name = "facultadDataGridView";
            this.facultadDataGridView.Size = new System.Drawing.Size(346, 250);
            this.facultadDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "IdFacultad";
            this.dataGridViewTextBoxColumn1.HeaderText = "IdFacultad";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "NombreFacultad";
            this.dataGridViewTextBoxColumn2.HeaderText = "NombreFacultad";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Admisiones_idAdmisiones";
            this.dataGridViewTextBoxColumn3.HeaderText = "Admisiones_idAdmisiones";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // Atras
            // 
            this.Atras.Location = new System.Drawing.Point(694, 139);
            this.Atras.Name = "Atras";
            this.Atras.Size = new System.Drawing.Size(75, 23);
            this.Atras.TabIndex = 2;
            this.Atras.Text = "Atras";
            this.Atras.UseVisualStyleBackColor = true;
            this.Atras.Click += new System.EventHandler(this.Atras_Click);
            // 
            // idFacultadTextBox
            // 
            this.idFacultadTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.facultadBindingSource, "IdFacultad", true));
            this.idFacultadTextBox.Location = new System.Drawing.Point(521, 329);
            this.idFacultadTextBox.Name = "idFacultadTextBox";
            this.idFacultadTextBox.Size = new System.Drawing.Size(100, 20);
            this.idFacultadTextBox.TabIndex = 4;
            // 
            // nombreFacultadTextBox
            // 
            this.nombreFacultadTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.facultadBindingSource, "NombreFacultad", true));
            this.nombreFacultadTextBox.Location = new System.Drawing.Point(521, 355);
            this.nombreFacultadTextBox.Name = "nombreFacultadTextBox";
            this.nombreFacultadTextBox.Size = new System.Drawing.Size(100, 20);
            this.nombreFacultadTextBox.TabIndex = 6;
            // 
            // admisiones_idAdmisionesTextBox
            // 
            this.admisiones_idAdmisionesTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.facultadBindingSource, "Admisiones_idAdmisiones", true));
            this.admisiones_idAdmisionesTextBox.Location = new System.Drawing.Point(521, 381);
            this.admisiones_idAdmisionesTextBox.Name = "admisiones_idAdmisionesTextBox";
            this.admisiones_idAdmisionesTextBox.Size = new System.Drawing.Size(100, 20);
            this.admisiones_idAdmisionesTextBox.TabIndex = 8;
            // 
            // Facultad
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::internacionalizacion.Properties.Resources.world_map_wallpaper_hd_9090;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1333, 616);
            this.Controls.Add(idFacultadLabel);
            this.Controls.Add(this.idFacultadTextBox);
            this.Controls.Add(nombreFacultadLabel);
            this.Controls.Add(this.nombreFacultadTextBox);
            this.Controls.Add(admisiones_idAdmisionesLabel);
            this.Controls.Add(this.admisiones_idAdmisionesTextBox);
            this.Controls.Add(this.Atras);
            this.Controls.Add(this.facultadDataGridView);
            this.Controls.Add(this.facultadBindingNavigator);
            this.Name = "Facultad";
            this.Text = "Facultad";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Facultad_Load);
            ((System.ComponentModel.ISupportInitialize)(this.internacionalizacionDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.facultadBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.facultadBindingNavigator)).EndInit();
            this.facultadBindingNavigator.ResumeLayout(false);
            this.facultadBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.facultadDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private internacionalizacionDataSet2 internacionalizacionDataSet2;
        private System.Windows.Forms.BindingSource facultadBindingSource;
        private internacionalizacionDataSet2TableAdapters.FacultadTableAdapter facultadTableAdapter;
        private internacionalizacionDataSet2TableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator facultadBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton facultadBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView facultadDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.Button Atras;
        private System.Windows.Forms.TextBox idFacultadTextBox;
        private System.Windows.Forms.TextBox nombreFacultadTextBox;
        private System.Windows.Forms.TextBox admisiones_idAdmisionesTextBox;
    }
}