﻿namespace internacionalizacion
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Estudiante = new System.Windows.Forms.Button();
            this.Facultad = new System.Windows.Forms.Button();
            this.Admisiones = new System.Windows.Forms.Button();
            this.Programa = new System.Windows.Forms.Button();
            this.Universidad = new System.Windows.Forms.Button();
            this.Materias = new System.Windows.Forms.Button();
            this.Notas = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Atras = new System.Windows.Forms.Button();
            this.dataSet1 = new System.Data.DataSet();
            this.dataTable1 = new System.Data.DataTable();
            this.dataColumn1 = new System.Data.DataColumn();
            this.dataColumn2 = new System.Data.DataColumn();
            this.dataTable2 = new System.Data.DataTable();
            this.dataColumn3 = new System.Data.DataColumn();
            this.dataColumn4 = new System.Data.DataColumn();
            this.Solicitud = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable2)).BeginInit();
            this.SuspendLayout();
            // 
            // Estudiante
            // 
            this.Estudiante.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.Estudiante.Location = new System.Drawing.Point(548, 210);
            this.Estudiante.Name = "Estudiante";
            this.Estudiante.Size = new System.Drawing.Size(78, 36);
            this.Estudiante.TabIndex = 0;
            this.Estudiante.Text = "Estudiante";
            this.Estudiante.UseVisualStyleBackColor = false;
            this.Estudiante.Click += new System.EventHandler(this.Estudiante_Click);
            // 
            // Facultad
            // 
            this.Facultad.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.Facultad.Location = new System.Drawing.Point(548, 297);
            this.Facultad.Name = "Facultad";
            this.Facultad.Size = new System.Drawing.Size(78, 36);
            this.Facultad.TabIndex = 2;
            this.Facultad.Text = "Facultad";
            this.Facultad.UseVisualStyleBackColor = false;
            this.Facultad.Click += new System.EventHandler(this.Facultad_Click);
            // 
            // Admisiones
            // 
            this.Admisiones.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.Admisiones.Location = new System.Drawing.Point(783, 297);
            this.Admisiones.Name = "Admisiones";
            this.Admisiones.Size = new System.Drawing.Size(78, 36);
            this.Admisiones.TabIndex = 3;
            this.Admisiones.Text = "Admisiones";
            this.Admisiones.UseVisualStyleBackColor = false;
            this.Admisiones.Click += new System.EventHandler(this.Admisiones_Click);
            // 
            // Programa
            // 
            this.Programa.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.Programa.Location = new System.Drawing.Point(548, 375);
            this.Programa.Name = "Programa";
            this.Programa.Size = new System.Drawing.Size(78, 36);
            this.Programa.TabIndex = 4;
            this.Programa.Text = "Programa";
            this.Programa.UseVisualStyleBackColor = false;
            this.Programa.Click += new System.EventHandler(this.Programa_Click);
            // 
            // Universidad
            // 
            this.Universidad.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.Universidad.Location = new System.Drawing.Point(783, 375);
            this.Universidad.Name = "Universidad";
            this.Universidad.Size = new System.Drawing.Size(78, 36);
            this.Universidad.TabIndex = 5;
            this.Universidad.Text = "Universidad";
            this.Universidad.UseVisualStyleBackColor = false;
            this.Universidad.Click += new System.EventHandler(this.Universidad_Click);
            // 
            // Materias
            // 
            this.Materias.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.Materias.Location = new System.Drawing.Point(548, 444);
            this.Materias.Name = "Materias";
            this.Materias.Size = new System.Drawing.Size(78, 36);
            this.Materias.TabIndex = 6;
            this.Materias.Text = "Materias";
            this.Materias.UseVisualStyleBackColor = false;
            this.Materias.Click += new System.EventHandler(this.Materias_Click);
            // 
            // Notas
            // 
            this.Notas.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.Notas.Location = new System.Drawing.Point(783, 444);
            this.Notas.Name = "Notas";
            this.Notas.Size = new System.Drawing.Size(78, 36);
            this.Notas.TabIndex = 8;
            this.Notas.Text = "Notas";
            this.Notas.UseVisualStyleBackColor = false;
            this.Notas.Click += new System.EventHandler(this.Notas_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label1.Location = new System.Drawing.Point(595, 117);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(209, 26);
            this.label1.TabIndex = 9;
            this.label1.Text = "tablas para la gestion de la Base de Datos \r\n               de internacionalizaci" +
    "on ";
            // 
            // Atras
            // 
            this.Atras.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.Atras.Location = new System.Drawing.Point(229, 304);
            this.Atras.Name = "Atras";
            this.Atras.Size = new System.Drawing.Size(75, 23);
            this.Atras.TabIndex = 10;
            this.Atras.Text = "<- Atras";
            this.Atras.UseVisualStyleBackColor = false;
            this.Atras.Click += new System.EventHandler(this.Atras_Click);
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "NewDataSet";
            this.dataSet1.Relations.AddRange(new System.Data.DataRelation[] {
            new System.Data.DataRelation("Relation1", "facultad", "solicitud", new string[] {
                        "Idfacultad"}, new string[] {
                        "facultad_idfacultad"}, false)});
            this.dataSet1.Tables.AddRange(new System.Data.DataTable[] {
            this.dataTable1,
            this.dataTable2});
            // 
            // dataTable1
            // 
            this.dataTable1.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn1,
            this.dataColumn2});
            this.dataTable1.Constraints.AddRange(new System.Data.Constraint[] {
            new System.Data.UniqueConstraint("Constraint1", new string[] {
                        "Idfacultad"}, true)});
            this.dataTable1.PrimaryKey = new System.Data.DataColumn[] {
        this.dataColumn1};
            this.dataTable1.TableName = "facultad";
            // 
            // dataColumn1
            // 
            this.dataColumn1.AllowDBNull = false;
            this.dataColumn1.ColumnName = "Idfacultad";
            // 
            // dataColumn2
            // 
            this.dataColumn2.ColumnName = "NombreFacultad";
            // 
            // dataTable2
            // 
            this.dataTable2.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn3,
            this.dataColumn4});
            this.dataTable2.Constraints.AddRange(new System.Data.Constraint[] {
            new System.Data.UniqueConstraint("Constraint1", new string[] {
                        "Idsolicitud"}, true),
            new System.Data.ForeignKeyConstraint("Relation1", "facultad", new string[] {
                        "Idfacultad"}, new string[] {
                        "facultad_idfacultad"}, System.Data.AcceptRejectRule.None, System.Data.Rule.Cascade, System.Data.Rule.Cascade)});
            this.dataTable2.PrimaryKey = new System.Data.DataColumn[] {
        this.dataColumn3};
            this.dataTable2.TableName = "solicitud";
            // 
            // dataColumn3
            // 
            this.dataColumn3.AllowDBNull = false;
            this.dataColumn3.ColumnName = "Idsolicitud";
            // 
            // dataColumn4
            // 
            this.dataColumn4.ColumnName = "facultad_idfacultad";
            // 
            // Solicitud
            // 
            this.Solicitud.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.Solicitud.Location = new System.Drawing.Point(783, 210);
            this.Solicitud.Name = "Solicitud";
            this.Solicitud.Size = new System.Drawing.Size(78, 36);
            this.Solicitud.TabIndex = 11;
            this.Solicitud.Text = "Solicitud";
            this.Solicitud.UseVisualStyleBackColor = false;
            this.Solicitud.Click += new System.EventHandler(this.Solicitud_Click);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::internacionalizacion.Properties.Resources.world_map_wallpaper_hd_9090;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1123, 568);
            this.Controls.Add(this.Solicitud);
            this.Controls.Add(this.Atras);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Notas);
            this.Controls.Add(this.Materias);
            this.Controls.Add(this.Universidad);
            this.Controls.Add(this.Programa);
            this.Controls.Add(this.Admisiones);
            this.Controls.Add(this.Facultad);
            this.Controls.Add(this.Estudiante);
            this.Name = "Menu";
            this.Text = "Form2";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Menu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Estudiante;
        private System.Windows.Forms.Button Facultad;
        private System.Windows.Forms.Button Admisiones;
        private System.Windows.Forms.Button Programa;
        private System.Windows.Forms.Button Universidad;
        private System.Windows.Forms.Button Materias;
        private System.Windows.Forms.Button Notas;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Atras;
        private System.Data.DataSet dataSet1;
        private System.Data.DataTable dataTable1;
        private System.Data.DataColumn dataColumn1;
        private System.Data.DataColumn dataColumn2;
        private System.Data.DataTable dataTable2;
        private System.Data.DataColumn dataColumn3;
        private System.Data.DataColumn dataColumn4;
        private System.Windows.Forms.Button Solicitud;
    }
}