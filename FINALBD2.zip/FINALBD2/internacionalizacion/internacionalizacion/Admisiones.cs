﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace internacionalizacion
{
    public partial class Admisiones : Form
    {
        public Admisiones()
        {
            InitializeComponent();
        }

        private void admisionesBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.admisionesBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.internacionalizacionDataSet2);

        }

        private void Admisiones_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'internacionalizacionDataSet2.Admisiones' Puede moverla o quitarla según sea necesario.
            this.admisionesTableAdapter.Fill(this.internacionalizacionDataSet2.Admisiones);

        }

        private void Atras_Click(object sender, EventArgs e)
        {
            this.Hide();
            Menu jframe = new Menu();
            jframe.Show();
        }
    }
}
