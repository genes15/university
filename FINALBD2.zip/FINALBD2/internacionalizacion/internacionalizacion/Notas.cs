﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace internacionalizacion
{
    public partial class Notas : Form
    {
        public Notas()
        {
            InitializeComponent();
        }

        private void notasBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.notasBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.internacionalizacionDataSet2);

        }

        private void Notas_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'internacionalizacionDataSet2.Notas' Puede moverla o quitarla según sea necesario.
            this.notasTableAdapter.Fill(this.internacionalizacionDataSet2.Notas);

        }

        private void Atras_Click(object sender, EventArgs e)
        {
            this.Hide();
            Menu jframe = new Menu();
            jframe.Show();
        }
    }
}
