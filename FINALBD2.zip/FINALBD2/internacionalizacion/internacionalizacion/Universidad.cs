﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace internacionalizacion
{
    public partial class Universidad : Form
    {
        public Universidad()
        {
            InitializeComponent();
        }

        private void universidadBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.universidadBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.internacionalizacionDataSet2);

        }

        private void Universidad_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'internacionalizacionDataSet2.Universidad' Puede moverla o quitarla según sea necesario.
            this.universidadTableAdapter.Fill(this.internacionalizacionDataSet2.Universidad);

        }

        private void Atras_Click(object sender, EventArgs e)
        {
            this.Hide();
            Menu jframe = new Menu();
            jframe.Show();
        }
    }
}
