﻿namespace internacionalizacion
{
    partial class Admisiones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label idAmisionesLabel;
            System.Windows.Forms.Label notas_IDnotasLabel;
            System.Windows.Forms.Label notas_estudiantes_IdestuadiantesLabel;
            System.Windows.Forms.Label notas_Materi_idmateriaLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admisiones));
            this.internacionalizacionDataSet2 = new internacionalizacion.internacionalizacionDataSet2();
            this.admisionesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.admisionesTableAdapter = new internacionalizacion.internacionalizacionDataSet2TableAdapters.AdmisionesTableAdapter();
            this.tableAdapterManager = new internacionalizacion.internacionalizacionDataSet2TableAdapters.TableAdapterManager();
            this.admisionesBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.admisionesBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.admisionesDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Atras = new System.Windows.Forms.Button();
            this.idAmisionesTextBox = new System.Windows.Forms.TextBox();
            this.notas_IDnotasTextBox = new System.Windows.Forms.TextBox();
            this.notas_estudiantes_IdestuadiantesTextBox = new System.Windows.Forms.TextBox();
            this.notas_Materi_idmateriaTextBox = new System.Windows.Forms.TextBox();
            idAmisionesLabel = new System.Windows.Forms.Label();
            notas_IDnotasLabel = new System.Windows.Forms.Label();
            notas_estudiantes_IdestuadiantesLabel = new System.Windows.Forms.Label();
            notas_Materi_idmateriaLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.internacionalizacionDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.admisionesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.admisionesBindingNavigator)).BeginInit();
            this.admisionesBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.admisionesDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // idAmisionesLabel
            // 
            idAmisionesLabel.AutoSize = true;
            idAmisionesLabel.BackColor = System.Drawing.SystemColors.ActiveBorder;
            idAmisionesLabel.Location = new System.Drawing.Point(372, 364);
            idAmisionesLabel.Name = "idAmisionesLabel";
            idAmisionesLabel.Size = new System.Drawing.Size(69, 13);
            idAmisionesLabel.TabIndex = 3;
            idAmisionesLabel.Text = "Id Amisiones:";
            // 
            // notas_IDnotasLabel
            // 
            notas_IDnotasLabel.AutoSize = true;
            notas_IDnotasLabel.BackColor = System.Drawing.SystemColors.ActiveBorder;
            notas_IDnotasLabel.Location = new System.Drawing.Point(372, 390);
            notas_IDnotasLabel.Name = "notas_IDnotasLabel";
            notas_IDnotasLabel.Size = new System.Drawing.Size(78, 13);
            notas_IDnotasLabel.TabIndex = 5;
            notas_IDnotasLabel.Text = "Notas IDnotas:";
            // 
            // notas_estudiantes_IdestuadiantesLabel
            // 
            notas_estudiantes_IdestuadiantesLabel.AutoSize = true;
            notas_estudiantes_IdestuadiantesLabel.BackColor = System.Drawing.SystemColors.ActiveBorder;
            notas_estudiantes_IdestuadiantesLabel.Location = new System.Drawing.Point(372, 416);
            notas_estudiantes_IdestuadiantesLabel.Name = "notas_estudiantes_IdestuadiantesLabel";
            notas_estudiantes_IdestuadiantesLabel.Size = new System.Drawing.Size(167, 13);
            notas_estudiantes_IdestuadiantesLabel.TabIndex = 7;
            notas_estudiantes_IdestuadiantesLabel.Text = "Notas estudiantes Idestuadiantes:";
            // 
            // notas_Materi_idmateriaLabel
            // 
            notas_Materi_idmateriaLabel.AutoSize = true;
            notas_Materi_idmateriaLabel.BackColor = System.Drawing.SystemColors.ActiveBorder;
            notas_Materi_idmateriaLabel.Location = new System.Drawing.Point(372, 442);
            notas_Materi_idmateriaLabel.Name = "notas_Materi_idmateriaLabel";
            notas_Materi_idmateriaLabel.Size = new System.Drawing.Size(115, 13);
            notas_Materi_idmateriaLabel.TabIndex = 9;
            notas_Materi_idmateriaLabel.Text = "Notas Materi idmateria:";
            // 
            // internacionalizacionDataSet2
            // 
            this.internacionalizacionDataSet2.DataSetName = "internacionalizacionDataSet2";
            this.internacionalizacionDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // admisionesBindingSource
            // 
            this.admisionesBindingSource.DataMember = "Admisiones";
            this.admisionesBindingSource.DataSource = this.internacionalizacionDataSet2;
            // 
            // admisionesTableAdapter
            // 
            this.admisionesTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AdmisionesTableAdapter = this.admisionesTableAdapter;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.EstudianteTableAdapter = null;
            this.tableAdapterManager.FacultadTableAdapter = null;
            this.tableAdapterManager.MateriaTableAdapter = null;
            this.tableAdapterManager.NotasTableAdapter = null;
            this.tableAdapterManager.programaTableAdapter = null;
            this.tableAdapterManager.SolicitudTableAdapter = null;
            this.tableAdapterManager.UniversidadTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = internacionalizacion.internacionalizacionDataSet2TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // admisionesBindingNavigator
            // 
            this.admisionesBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.admisionesBindingNavigator.BindingSource = this.admisionesBindingSource;
            this.admisionesBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.admisionesBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.admisionesBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.admisionesBindingNavigatorSaveItem});
            this.admisionesBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.admisionesBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.admisionesBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.admisionesBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.admisionesBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.admisionesBindingNavigator.Name = "admisionesBindingNavigator";
            this.admisionesBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.admisionesBindingNavigator.Size = new System.Drawing.Size(1270, 25);
            this.admisionesBindingNavigator.TabIndex = 0;
            this.admisionesBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Agregar nuevo";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 22);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Número total de elementos";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Eliminar";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Mover primero";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Mover anterior";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Posición";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Posición actual";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Mover siguiente";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Mover último";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // admisionesBindingNavigatorSaveItem
            // 
            this.admisionesBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.admisionesBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("admisionesBindingNavigatorSaveItem.Image")));
            this.admisionesBindingNavigatorSaveItem.Name = "admisionesBindingNavigatorSaveItem";
            this.admisionesBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.admisionesBindingNavigatorSaveItem.Text = "Guardar datos";
            this.admisionesBindingNavigatorSaveItem.Click += new System.EventHandler(this.admisionesBindingNavigatorSaveItem_Click);
            // 
            // admisionesDataGridView
            // 
            this.admisionesDataGridView.AutoGenerateColumns = false;
            this.admisionesDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.admisionesDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.admisionesDataGridView.DataSource = this.admisionesBindingSource;
            this.admisionesDataGridView.Location = new System.Drawing.Point(815, 296);
            this.admisionesDataGridView.Name = "admisionesDataGridView";
            this.admisionesDataGridView.Size = new System.Drawing.Size(443, 212);
            this.admisionesDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "IdAmisiones";
            this.dataGridViewTextBoxColumn1.HeaderText = "IdAmisiones";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Notas_IDnotas";
            this.dataGridViewTextBoxColumn2.HeaderText = "Notas_IDnotas";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Notas_estudiantes_Idestuadiantes";
            this.dataGridViewTextBoxColumn3.HeaderText = "Notas_estudiantes_Idestuadiantes";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Notas_Materi_idmateria";
            this.dataGridViewTextBoxColumn4.HeaderText = "Notas_Materi_idmateria";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // Atras
            // 
            this.Atras.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.Atras.Location = new System.Drawing.Point(691, 146);
            this.Atras.Name = "Atras";
            this.Atras.Size = new System.Drawing.Size(75, 23);
            this.Atras.TabIndex = 2;
            this.Atras.Text = "Atras";
            this.Atras.UseVisualStyleBackColor = false;
            this.Atras.Click += new System.EventHandler(this.Atras_Click);
            // 
            // idAmisionesTextBox
            // 
            this.idAmisionesTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.admisionesBindingSource, "IdAmisiones", true));
            this.idAmisionesTextBox.Location = new System.Drawing.Point(545, 361);
            this.idAmisionesTextBox.Name = "idAmisionesTextBox";
            this.idAmisionesTextBox.Size = new System.Drawing.Size(100, 20);
            this.idAmisionesTextBox.TabIndex = 4;
            // 
            // notas_IDnotasTextBox
            // 
            this.notas_IDnotasTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.admisionesBindingSource, "Notas_IDnotas", true));
            this.notas_IDnotasTextBox.Location = new System.Drawing.Point(545, 387);
            this.notas_IDnotasTextBox.Name = "notas_IDnotasTextBox";
            this.notas_IDnotasTextBox.Size = new System.Drawing.Size(100, 20);
            this.notas_IDnotasTextBox.TabIndex = 6;
            // 
            // notas_estudiantes_IdestuadiantesTextBox
            // 
            this.notas_estudiantes_IdestuadiantesTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.admisionesBindingSource, "Notas_estudiantes_Idestuadiantes", true));
            this.notas_estudiantes_IdestuadiantesTextBox.Location = new System.Drawing.Point(545, 413);
            this.notas_estudiantes_IdestuadiantesTextBox.Name = "notas_estudiantes_IdestuadiantesTextBox";
            this.notas_estudiantes_IdestuadiantesTextBox.Size = new System.Drawing.Size(100, 20);
            this.notas_estudiantes_IdestuadiantesTextBox.TabIndex = 8;
            // 
            // notas_Materi_idmateriaTextBox
            // 
            this.notas_Materi_idmateriaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.admisionesBindingSource, "Notas_Materi_idmateria", true));
            this.notas_Materi_idmateriaTextBox.Location = new System.Drawing.Point(545, 439);
            this.notas_Materi_idmateriaTextBox.Name = "notas_Materi_idmateriaTextBox";
            this.notas_Materi_idmateriaTextBox.Size = new System.Drawing.Size(100, 20);
            this.notas_Materi_idmateriaTextBox.TabIndex = 10;
            // 
            // Admisiones
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::internacionalizacion.Properties.Resources.world_map_wallpaper_hd_9090;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1270, 520);
            this.Controls.Add(idAmisionesLabel);
            this.Controls.Add(this.idAmisionesTextBox);
            this.Controls.Add(notas_IDnotasLabel);
            this.Controls.Add(this.notas_IDnotasTextBox);
            this.Controls.Add(notas_estudiantes_IdestuadiantesLabel);
            this.Controls.Add(this.notas_estudiantes_IdestuadiantesTextBox);
            this.Controls.Add(notas_Materi_idmateriaLabel);
            this.Controls.Add(this.notas_Materi_idmateriaTextBox);
            this.Controls.Add(this.Atras);
            this.Controls.Add(this.admisionesDataGridView);
            this.Controls.Add(this.admisionesBindingNavigator);
            this.Name = "Admisiones";
            this.Text = "Admisiones";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Admisiones_Load);
            ((System.ComponentModel.ISupportInitialize)(this.internacionalizacionDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.admisionesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.admisionesBindingNavigator)).EndInit();
            this.admisionesBindingNavigator.ResumeLayout(false);
            this.admisionesBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.admisionesDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private internacionalizacionDataSet2 internacionalizacionDataSet2;
        private System.Windows.Forms.BindingSource admisionesBindingSource;
        private internacionalizacionDataSet2TableAdapters.AdmisionesTableAdapter admisionesTableAdapter;
        private internacionalizacionDataSet2TableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator admisionesBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton admisionesBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView admisionesDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.Button Atras;
        private System.Windows.Forms.TextBox idAmisionesTextBox;
        private System.Windows.Forms.TextBox notas_IDnotasTextBox;
        private System.Windows.Forms.TextBox notas_estudiantes_IdestuadiantesTextBox;
        private System.Windows.Forms.TextBox notas_Materi_idmateriaTextBox;
    }
}