﻿namespace internacionalizacion
{
    partial class Solicitud
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label idSolicitudLabel;
            System.Windows.Forms.Label facultad_idfacultadLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Solicitud));
            this.internacionalizacionDataSet2 = new internacionalizacion.internacionalizacionDataSet2();
            this.solicitudBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.solicitudTableAdapter = new internacionalizacion.internacionalizacionDataSet2TableAdapters.SolicitudTableAdapter();
            this.tableAdapterManager = new internacionalizacion.internacionalizacionDataSet2TableAdapters.TableAdapterManager();
            this.solicitudBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.solicitudBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.solicitudDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Atras = new System.Windows.Forms.Button();
            this.idSolicitudTextBox = new System.Windows.Forms.TextBox();
            this.facultad_idfacultadTextBox = new System.Windows.Forms.TextBox();
            idSolicitudLabel = new System.Windows.Forms.Label();
            facultad_idfacultadLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.internacionalizacionDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.solicitudBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.solicitudBindingNavigator)).BeginInit();
            this.solicitudBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.solicitudDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // idSolicitudLabel
            // 
            idSolicitudLabel.AutoSize = true;
            idSolicitudLabel.BackColor = System.Drawing.SystemColors.ActiveBorder;
            idSolicitudLabel.Location = new System.Drawing.Point(489, 384);
            idSolicitudLabel.Name = "idSolicitudLabel";
            idSolicitudLabel.Size = new System.Drawing.Size(62, 13);
            idSolicitudLabel.TabIndex = 3;
            idSolicitudLabel.Text = "Id Solicitud:";
            // 
            // facultad_idfacultadLabel
            // 
            facultad_idfacultadLabel.AutoSize = true;
            facultad_idfacultadLabel.BackColor = System.Drawing.SystemColors.ActiveBorder;
            facultad_idfacultadLabel.Location = new System.Drawing.Point(489, 410);
            facultad_idfacultadLabel.Name = "facultad_idfacultadLabel";
            facultad_idfacultadLabel.Size = new System.Drawing.Size(100, 13);
            facultad_idfacultadLabel.TabIndex = 5;
            facultad_idfacultadLabel.Text = "Facultad idfacultad:";
            // 
            // internacionalizacionDataSet2
            // 
            this.internacionalizacionDataSet2.DataSetName = "internacionalizacionDataSet2";
            this.internacionalizacionDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // solicitudBindingSource
            // 
            this.solicitudBindingSource.DataMember = "Solicitud";
            this.solicitudBindingSource.DataSource = this.internacionalizacionDataSet2;
            // 
            // solicitudTableAdapter
            // 
            this.solicitudTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AdmisionesTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.EstudianteTableAdapter = null;
            this.tableAdapterManager.FacultadTableAdapter = null;
            this.tableAdapterManager.MateriaTableAdapter = null;
            this.tableAdapterManager.NotasTableAdapter = null;
            this.tableAdapterManager.programaTableAdapter = null;
            this.tableAdapterManager.SolicitudTableAdapter = this.solicitudTableAdapter;
            this.tableAdapterManager.UniversidadTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = internacionalizacion.internacionalizacionDataSet2TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // solicitudBindingNavigator
            // 
            this.solicitudBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.solicitudBindingNavigator.BindingSource = this.solicitudBindingSource;
            this.solicitudBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.solicitudBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.solicitudBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.solicitudBindingNavigatorSaveItem});
            this.solicitudBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.solicitudBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.solicitudBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.solicitudBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.solicitudBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.solicitudBindingNavigator.Name = "solicitudBindingNavigator";
            this.solicitudBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.solicitudBindingNavigator.Size = new System.Drawing.Size(1282, 25);
            this.solicitudBindingNavigator.TabIndex = 0;
            this.solicitudBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Agregar nuevo";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 22);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Número total de elementos";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Eliminar";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Mover primero";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Mover anterior";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Posición";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Posición actual";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Mover siguiente";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Mover último";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // solicitudBindingNavigatorSaveItem
            // 
            this.solicitudBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.solicitudBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("solicitudBindingNavigatorSaveItem.Image")));
            this.solicitudBindingNavigatorSaveItem.Name = "solicitudBindingNavigatorSaveItem";
            this.solicitudBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.solicitudBindingNavigatorSaveItem.Text = "Guardar datos";
            this.solicitudBindingNavigatorSaveItem.Click += new System.EventHandler(this.solicitudBindingNavigatorSaveItem_Click);
            // 
            // solicitudDataGridView
            // 
            this.solicitudDataGridView.AutoGenerateColumns = false;
            this.solicitudDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.solicitudDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.solicitudDataGridView.DataSource = this.solicitudBindingSource;
            this.solicitudDataGridView.Location = new System.Drawing.Point(862, 319);
            this.solicitudDataGridView.Name = "solicitudDataGridView";
            this.solicitudDataGridView.Size = new System.Drawing.Size(300, 220);
            this.solicitudDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "IdSolicitud";
            this.dataGridViewTextBoxColumn1.HeaderText = "IdSolicitud";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Facultad_idfacultad";
            this.dataGridViewTextBoxColumn2.HeaderText = "Facultad_idfacultad";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // Atras
            // 
            this.Atras.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.Atras.Location = new System.Drawing.Point(754, 169);
            this.Atras.Name = "Atras";
            this.Atras.Size = new System.Drawing.Size(70, 30);
            this.Atras.TabIndex = 2;
            this.Atras.Text = "Atras";
            this.Atras.UseVisualStyleBackColor = false;
            this.Atras.Click += new System.EventHandler(this.Atras_Click);
            // 
            // idSolicitudTextBox
            // 
            this.idSolicitudTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.solicitudBindingSource, "IdSolicitud", true));
            this.idSolicitudTextBox.Location = new System.Drawing.Point(595, 381);
            this.idSolicitudTextBox.Name = "idSolicitudTextBox";
            this.idSolicitudTextBox.Size = new System.Drawing.Size(100, 20);
            this.idSolicitudTextBox.TabIndex = 4;
            // 
            // facultad_idfacultadTextBox
            // 
            this.facultad_idfacultadTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.solicitudBindingSource, "Facultad_idfacultad", true));
            this.facultad_idfacultadTextBox.Location = new System.Drawing.Point(595, 407);
            this.facultad_idfacultadTextBox.Name = "facultad_idfacultadTextBox";
            this.facultad_idfacultadTextBox.Size = new System.Drawing.Size(100, 20);
            this.facultad_idfacultadTextBox.TabIndex = 6;
            // 
            // Solicitud
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::internacionalizacion.Properties.Resources.world_map_wallpaper_hd_9090;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1282, 578);
            this.Controls.Add(idSolicitudLabel);
            this.Controls.Add(this.idSolicitudTextBox);
            this.Controls.Add(facultad_idfacultadLabel);
            this.Controls.Add(this.facultad_idfacultadTextBox);
            this.Controls.Add(this.Atras);
            this.Controls.Add(this.solicitudDataGridView);
            this.Controls.Add(this.solicitudBindingNavigator);
            this.Name = "Solicitud";
            this.Text = "Solicitud";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Solicitud_Load);
            ((System.ComponentModel.ISupportInitialize)(this.internacionalizacionDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.solicitudBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.solicitudBindingNavigator)).EndInit();
            this.solicitudBindingNavigator.ResumeLayout(false);
            this.solicitudBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.solicitudDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private internacionalizacionDataSet2 internacionalizacionDataSet2;
        private System.Windows.Forms.BindingSource solicitudBindingSource;
        private internacionalizacionDataSet2TableAdapters.SolicitudTableAdapter solicitudTableAdapter;
        private internacionalizacionDataSet2TableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator solicitudBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton solicitudBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView solicitudDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.Button Atras;
        private System.Windows.Forms.TextBox idSolicitudTextBox;
        private System.Windows.Forms.TextBox facultad_idfacultadTextBox;
    }
}